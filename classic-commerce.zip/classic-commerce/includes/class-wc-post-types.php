<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 *
 * @package ClassicCommerce/Classes/Products
 * @version WC-2.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class WC_Post_Types {

	/**
	 * Hook in methods.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ), 5 );
		add_action( 'init', array( __CLASS__, 'register_post_types' ), 5 );
		add_action( 'init', array( __CLASS__, 'register_post_status' ), 9 );
        add_filter( 'term_updated_messages', array( __CLASS__, 'updated_term_messages' ) );
		add_filter( 'rest_api_allowed_post_types', array( __CLASS__, 'rest_api_allowed_post_types' ) );
		add_action( 'woocommerce_after_register_post_type', array( __CLASS__, 'maybe_flush_rewrite_rules' ) );
		add_action( 'woocommerce_flush_rewrite_rules', array( __CLASS__, 'flush_rewrite_rules' ) );
	}

	/**
	 * Register core taxonomies.
	 */
	public static function register_taxonomies() {

		if ( ! is_blog_installed() ) {
			return;
		}

		if ( taxonomy_exists( 'product_type' ) ) {
			return;
		}

		do_action( 'woocommerce_register_taxonomy' );

		$permalinks = wc_get_permalink_structure();

		register_taxonomy(
			'product_type',
			apply_filters( 'woocommerce_taxonomy_objects_product_type', array( 'product' ) ),
			apply_filters(
				'woocommerce_taxonomy_args_product_type',
                array(
					'hierarchical'      => false,
					'show_ui'           => false,
					'show_in_nav_menus' => false,
					'query_var'         => is_admin(),
					'rewrite'           => false,
					'public'            => false,
				)
			)
		);

		register_taxonomy(
			'product_visibility',
			apply_filters( 'woocommerce_taxonomy_objects_product_visibility', array( 'product', 'product_variation' ) ),
			apply_filters(
				'woocommerce_taxonomy_args_product_visibility',
                array(
					'hierarchical'      => false,
					'show_ui'           => false,
					'show_in_nav_menus' => false,
					'query_var'         => is_admin(),
					'rewrite'           => false,
					'public'            => false,
				)
			)
		);

		register_taxonomy(
			'product_cat',
			apply_filters( 'woocommerce_taxonomy_objects_product_cat', array( 'product' ) ),
			apply_filters(
				'woocommerce_taxonomy_args_product_cat',
                array(
					'hierarchical'          => true,
					'update_count_callback' => '_wc_term_recount',
					'label'                 => __( 'Categories', 'classic-commerce' ),
					'labels'                => array(
						'name'              => __( 'Product categories', 'classic-commerce' ),
						'singular_name'     => __( 'Category', 'classic-commerce' ),
						'menu_name'         => _x( 'Categories', 'Admin menu name', 'classic-commerce' ),
						'search_items'      => __( 'Search categories', 'classic-commerce' ),
						'all_items'         => __( 'All categories', 'classic-commerce' ),
						'parent_item'       => __( 'Parent category', 'classic-commerce' ),
						'parent_item_colon' => __( 'Parent category:', 'classic-commerce' ),
						'edit_item'         => __( 'Edit category', 'classic-commerce' ),
						'update_item'       => __( 'Update category', 'classic-commerce' ),
						'add_new_item'      => __( 'Add new category', 'classic-commerce' ),
						'new_item_name'     => __( 'New category name', 'classic-commerce' ),
						'not_found'         => __( 'No categories found', 'classic-commerce' ),
					),
					'show_ui'               => true,
					'query_var'             => true,
					'capabilities'          => array(
						'manage_terms' => 'manage_product_terms',
						'edit_terms'   => 'edit_product_terms',
						'delete_terms' => 'delete_product_terms',
						'assign_terms' => 'assign_product_terms',
					),
					'rewrite'               => array(
						'slug'         => $permalinks['category_rewrite_slug'],
						'with_front'   => false,
						'hierarchical' => true,
					),
				)
			)
		);

		register_taxonomy(
			'product_tag',
			apply_filters( 'woocommerce_taxonomy_objects_product_tag', array( 'product' ) ),
			apply_filters(
				'woocommerce_taxonomy_args_product_tag',
                array(
					'hierarchical'          => false,
					'update_count_callback' => '_wc_term_recount',
					'label'                 => __( 'Product tags', 'classic-commerce' ),
					'labels'                => array(
						'name'                       => __( 'Product tags', 'classic-commerce' ),
						'singular_name'              => __( 'Tag', 'classic-commerce' ),
						'menu_name'                  => _x( 'Tags', 'Admin menu name', 'classic-commerce' ),
						'search_items'               => __( 'Search tags', 'classic-commerce' ),
						'all_items'                  => __( 'All tags', 'classic-commerce' ),
						'edit_item'                  => __( 'Edit tag', 'classic-commerce' ),
						'update_item'                => __( 'Update tag', 'classic-commerce' ),
						'add_new_item'               => __( 'Add new tag', 'classic-commerce' ),
						'new_item_name'              => __( 'New tag name', 'classic-commerce' ),
						'popular_items'              => __( 'Popular tags', 'classic-commerce' ),
						'separate_items_with_commas' => __( 'Separate tags with commas', 'classic-commerce' ),
						'add_or_remove_items'        => __( 'Add or remove tags', 'classic-commerce' ),
						'choose_from_most_used'      => __( 'Choose from the most used tags', 'classic-commerce' ),
						'not_found'                  => __( 'No tags found', 'classic-commerce' ),
					),
					'show_ui'               => true,
					'query_var'             => true,
					'capabilities'          => array(
						'manage_terms' => 'manage_product_terms',
						'edit_terms'   => 'edit_product_terms',
						'delete_terms' => 'delete_product_terms',
						'assign_terms' => 'assign_product_terms',
					),
					'rewrite'               => array(
						'slug'       => $permalinks['tag_rewrite_slug'],
						'with_front' => false,
					),
				)
			)
		);

		register_taxonomy(
			'product_shipping_class',
			apply_filters( 'woocommerce_taxonomy_objects_product_shipping_class', array( 'product', 'product_variation' ) ),
			apply_filters(
				'woocommerce_taxonomy_args_product_shipping_class',
                array(
					'hierarchical'          => false,
					'update_count_callback' => '_update_post_term_count',
					'label'                 => __( 'Shipping classes', 'classic-commerce' ),
					'labels'                => array(
						'name'              => __( 'Product shipping classes', 'classic-commerce' ),
						'singular_name'     => __( 'Shipping class', 'classic-commerce' ),
						'menu_name'         => _x( 'Shipping classes', 'Admin menu name', 'classic-commerce' ),
						'search_items'      => __( 'Search shipping classes', 'classic-commerce' ),
						'all_items'         => __( 'All shipping classes', 'classic-commerce' ),
						'parent_item'       => __( 'Parent shipping class', 'classic-commerce' ),
						'parent_item_colon' => __( 'Parent shipping class:', 'classic-commerce' ),
						'edit_item'         => __( 'Edit shipping class', 'classic-commerce' ),
						'update_item'       => __( 'Update shipping class', 'classic-commerce' ),
						'add_new_item'      => __( 'Add new shipping class', 'classic-commerce' ),
						'new_item_name'     => __( 'New shipping class Name', 'classic-commerce' ),
					),
					'show_ui'               => false,
					'show_in_quick_edit'    => false,
					'show_in_nav_menus'     => false,
					'query_var'             => is_admin(),
					'capabilities'          => array(
						'manage_terms' => 'manage_product_terms',
						'edit_terms'   => 'edit_product_terms',
						'delete_terms' => 'delete_product_terms',
						'assign_terms' => 'assign_product_terms',
					),
					'rewrite'               => false,
				)
			)
		);

		global $wc_product_attributes;

		$wc_product_attributes = array();
		$attribute_taxonomies  = wc_get_attribute_taxonomies();

		if ( $attribute_taxonomies ) {
			foreach ( $attribute_taxonomies as $tax ) {
				$name = wc_attribute_taxonomy_name( $tax->attribute_name );

				if ( $name ) {
					$tax->attribute_public          = absint( isset( $tax->attribute_public ) ? $tax->attribute_public : 1 );
					$label                          = ! empty( $tax->attribute_label ) ? $tax->attribute_label : $tax->attribute_name;
					$wc_product_attributes[ $name ] = $tax;
					$taxonomy_data                  = array(
						'hierarchical'          => false,
						'update_count_callback' => '_update_post_term_count',
						'labels'                => array(
							/* translators: %s: attribute name */
							'name'              => sprintf( _x( 'Product %s', 'Product Attribute', 'classic-commerce' ), $label ),
							'singular_name'     => $label,
							/* translators: %s: attribute name */
							'search_items'      => sprintf( __( 'Search %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'all_items'         => sprintf( __( 'All %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'parent_item'       => sprintf( __( 'Parent %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'parent_item_colon' => sprintf( __( 'Parent %s:', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'edit_item'         => sprintf( __( 'Edit %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'update_item'       => sprintf( __( 'Update %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'add_new_item'      => sprintf( __( 'Add new %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'new_item_name'     => sprintf( __( 'New %s', 'classic-commerce' ), $label ),
							/* translators: %s: attribute name */
							'not_found'         => sprintf( __( 'No &quot;%s&quot; found', 'classic-commerce' ), $label ),
                            /* translators: %s: attribute name */
							'back_to_items'     => sprintf( __( '&larr; Back to "%s" attributes', 'classic-commerce' ), $label ),
						),
						'show_ui'               => true,
						'show_in_quick_edit'    => false,
						'show_in_menu'          => false,
						'meta_box_cb'           => false,
						'query_var'             => 1 === $tax->attribute_public,
						'rewrite'               => false,
						'sort'                  => false,
						'public'                => 1 === $tax->attribute_public,
						'show_in_nav_menus'     => 1 === $tax->attribute_public && apply_filters( 'woocommerce_attribute_show_in_nav_menus', false, $name ),
						'capabilities'          => array(
							'manage_terms' => 'manage_product_terms',
							'edit_terms'   => 'edit_product_terms',
							'delete_terms' => 'delete_product_terms',
							'assign_terms' => 'assign_product_terms',
						),
					);

					if ( 1 === $tax->attribute_public && sanitize_title( $tax->attribute_name ) ) {
						$taxonomy_data['rewrite'] = array(
							'slug'         => trailingslashit( $permalinks['attribute_rewrite_slug'] ) . urldecode( sanitize_title( $tax->attribute_name ) ),
							'with_front'   => false,
							'hierarchical' => true,
						);
					}

					register_taxonomy( $name, apply_filters( "woocommerce_taxonomy_objects_{$name}", array( 'product' ) ), apply_filters( "woocommerce_taxonomy_args_{$name}", $taxonomy_data ) );
				}
			}
		}

		do_action( 'woocommerce_after_register_taxonomy' );
	}

	/**
	 * Register core post types.
	 */
	public static function register_post_types() {
		if ( ! is_blog_installed() || post_type_exists( 'product' ) ) {
			return;
		}

		do_action( 'woocommerce_register_post_type' );

		$permalinks = wc_get_permalink_structure();
		$supports   = array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'publicize', 'wpcom-markdown' );

		if ( 'yes' === get_option( 'woocommerce_enable_reviews', 'yes' ) ) {
			$supports[] = 'comments';
		}

		$shop_page_id = wc_get_page_id( 'shop' );

		if ( current_theme_supports( 'woocommerce' ) ) {
			$has_archive = $shop_page_id && get_post( $shop_page_id ) ? urldecode( get_page_uri( $shop_page_id ) ) : 'shop';
		} else {
			$has_archive = false;
		}

		// If theme support changes, we may need to flush permalinks since some are changed based on this flag.
		if ( update_option( 'current_theme_supports_woocommerce', current_theme_supports( 'woocommerce' ) ? 'yes' : 'no' ) ) {
			update_option( 'woocommerce_queue_flush_rewrite_rules', 'yes' );
		}

		register_post_type(
			'product',
			apply_filters(
				'woocommerce_register_post_type_product',
				array(
					'labels'              => array(
						'name'                  => __( 'Products', 'classic-commerce' ),
						'singular_name'         => __( 'Product', 'classic-commerce' ),
						'all_items'             => __( 'All Products', 'classic-commerce' ),
						'menu_name'             => _x( 'Products', 'Admin menu name', 'classic-commerce' ),
						'add_new'               => __( 'Add New', 'classic-commerce' ),
						'add_new_item'          => __( 'Add new product', 'classic-commerce' ),
						'edit'                  => __( 'Edit', 'classic-commerce' ),
						'edit_item'             => __( 'Edit product', 'classic-commerce' ),
						'new_item'              => __( 'New product', 'classic-commerce' ),
						'view_item'             => __( 'View product', 'classic-commerce' ),
						'view_items'            => __( 'View products', 'classic-commerce' ),
						'search_items'          => __( 'Search products', 'classic-commerce' ),
						'not_found'             => __( 'No products found', 'classic-commerce' ),
						'not_found_in_trash'    => __( 'No products found in trash', 'classic-commerce' ),
						'parent'                => __( 'Parent product', 'classic-commerce' ),
						'featured_image'        => __( 'Product image', 'classic-commerce' ),
						'set_featured_image'    => __( 'Set product image', 'classic-commerce' ),
						'remove_featured_image' => __( 'Remove product image', 'classic-commerce' ),
						'use_featured_image'    => __( 'Use as product image', 'classic-commerce' ),
						'insert_into_item'      => __( 'Insert into product', 'classic-commerce' ),
						'uploaded_to_this_item' => __( 'Uploaded to this product', 'classic-commerce' ),
						'filter_items_list'     => __( 'Filter products', 'classic-commerce' ),
						'items_list_navigation' => __( 'Products navigation', 'classic-commerce' ),
						'items_list'            => __( 'Products list', 'classic-commerce' ),
					),
					'description'         => __( 'This is where you can browse products in this store.', 'classic-commerce' ),
					'public'              => true,
					'show_ui'             => true,
					'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => $permalinks['product_rewrite_slug'] ? array(
						'slug'       => $permalinks['product_rewrite_slug'],
						'with_front' => false,
						'feeds'      => true,
					) : false,
					'query_var'           => true,
					'supports'            => $supports,
					'has_archive'         => $has_archive,
					'show_in_nav_menus'   => true,
                    'menu_icon'           => 'dashicons-products',
					'show_in_rest'        => true,
                    'rest_namespace'      => 'wp/v3',
				)
			)
		);

		register_post_type(
			'product_variation',
			apply_filters(
				'woocommerce_register_post_type_product_variation',
				array(
					'label'           => __( 'Variations', 'classic-commerce' ),
					'public'          => false,
					'hierarchical'    => false,
					'supports'        => false,
					'capability_type' => 'product',
					'rewrite'         => false,
				)
			)
		);

		wc_register_order_type(
			'shop_order',
			apply_filters(
				'woocommerce_register_post_type_shop_order',
				array(
					'labels'              => array(
						'name'                  => __( 'Orders', 'classic-commerce' ),
						'singular_name'         => _x( 'Order', 'shop_order post type singular name', 'classic-commerce' ),
						'add_new'               => __( 'Add order', 'classic-commerce' ),
						'add_new_item'          => __( 'Add new order', 'classic-commerce' ),
						'edit'                  => __( 'Edit', 'classic-commerce' ),
						'edit_item'             => __( 'Edit order', 'classic-commerce' ),
						'new_item'              => __( 'New order', 'classic-commerce' ),
						'view_item'             => __( 'View order', 'classic-commerce' ),
						'search_items'          => __( 'Search orders', 'classic-commerce' ),
						'not_found'             => __( 'No orders found', 'classic-commerce' ),
						'not_found_in_trash'    => __( 'No orders found in trash', 'classic-commerce' ),
						'parent'                => __( 'Parent orders', 'classic-commerce' ),
						'menu_name'             => _x( 'Orders', 'Admin menu name', 'classic-commerce' ),
						'filter_items_list'     => __( 'Filter orders', 'classic-commerce' ),
						'items_list_navigation' => __( 'Orders navigation', 'classic-commerce' ),
						'items_list'            => __( 'Orders list', 'classic-commerce' ),
					),
					'description'         => __( 'This is where store orders are stored.', 'classic-commerce' ),
					'public'              => false,
					'show_ui'             => true,
					'capability_type'     => 'shop_order',
					'map_meta_cap'        => true,
					'publicly_queryable'  => false,
					'exclude_from_search' => true,
					'show_in_menu'        => current_user_can( 'edit_others_shop_orders' ) ? 'woocommerce' : true,
					'hierarchical'        => false,
					'show_in_nav_menus'   => false,
					'rewrite'             => false,
					'query_var'           => false,
					'supports'            => array( 'title', 'comments', 'custom-fields' ),
					'has_archive'         => false,
				)
			)
		);

		wc_register_order_type(
			'shop_order_refund',
			apply_filters(
				'woocommerce_register_post_type_shop_order_refund',
				array(
					'label'                            => __( 'Refunds', 'classic-commerce' ),
					'capability_type'                  => 'shop_order',
					'public'                           => false,
					'hierarchical'                     => false,
					'supports'                         => false,
					'add_order_meta_boxes'             => false,
					'exclude_from_order_count'         => true,
					'exclude_from_order_views'         => false,
					'exclude_from_order_reports'       => false,
					'exclude_from_order_sales_reports' => true,
					'class_name'                       => 'WC_Order_Refund',
					'rewrite'                          => false,
				)
			)
		);

		if ( 'yes' === get_option( 'woocommerce_enable_coupons' ) ) {
			register_post_type(
				'shop_coupon',
				apply_filters(
					'woocommerce_register_post_type_shop_coupon',
					array(
						'labels'              => array(
							'name'                  => __( 'Coupons', 'classic-commerce' ),
							'singular_name'         => __( 'Coupon', 'classic-commerce' ),
							'menu_name'             => _x( 'Coupons', 'Admin menu name', 'classic-commerce' ),
							'add_new'               => __( 'Add coupon', 'classic-commerce' ),
							'add_new_item'          => __( 'Add new coupon', 'classic-commerce' ),
							'edit'                  => __( 'Edit', 'classic-commerce' ),
							'edit_item'             => __( 'Edit coupon', 'classic-commerce' ),
							'new_item'              => __( 'New coupon', 'classic-commerce' ),
							'view_item'             => __( 'View coupon', 'classic-commerce' ),
							'search_items'          => __( 'Search coupons', 'classic-commerce' ),
							'not_found'             => __( 'No coupons found', 'classic-commerce' ),
							'not_found_in_trash'    => __( 'No coupons found in trash', 'classic-commerce' ),
							'parent'                => __( 'Parent coupon', 'classic-commerce' ),
							'filter_items_list'     => __( 'Filter coupons', 'classic-commerce' ),
							'items_list_navigation' => __( 'Coupons navigation', 'classic-commerce' ),
							'items_list'            => __( 'Coupons list', 'classic-commerce' ),
						),
						'description'         => __( 'This is where you can add new coupons that customers can use in your store.', 'classic-commerce' ),
						'public'              => false,
						'show_ui'             => true,
						'capability_type'     => 'shop_coupon',
						'map_meta_cap'        => true,
						'publicly_queryable'  => false,
						'exclude_from_search' => true,
						'show_in_menu'        => current_user_can( 'edit_others_shop_orders' ) ? 'woocommerce' : true,
						'hierarchical'        => false,
						'rewrite'             => false,
						'query_var'           => false,
						'supports'            => array( 'title' ),
						'show_in_nav_menus'   => false,
						'show_in_admin_bar'   => true,
					)
				)
			);
		}

		do_action( 'woocommerce_after_register_post_type' );
	}

    /**
	 * Customize taxonomies update messages.
	 *
	 * @param array $messages The list of available messages.
	 * @since 4.4.0
	 * @return bool
	 */
	public static function updated_term_messages( $messages ) {
		$messages['product_cat'] = array(
			0 => '',
			1 => __( 'Category added.', 'classic-commerce' ),
			2 => __( 'Category deleted.', 'classic-commerce' ),
			3 => __( 'Category updated.', 'classic-commerce' ),
			4 => __( 'Category not added.', 'classic-commerce' ),
			5 => __( 'Category not updated.', 'classic-commerce' ),
			6 => __( 'Categories deleted.', 'classic-commerce' ),
		);

		$messages['product_tag'] = array(
			0 => '',
			1 => __( 'Tag added.', 'classic-commerce' ),
			2 => __( 'Tag deleted.', 'classic-commerce' ),
			3 => __( 'Tag updated.', 'classic-commerce' ),
			4 => __( 'Tag not added.', 'classic-commerce' ),
			5 => __( 'Tag not updated.', 'classic-commerce' ),
			6 => __( 'Tags deleted.', 'classic-commerce' ),
		);

		$wc_product_attributes = array();
		$attribute_taxonomies  = wc_get_attribute_taxonomies();

		if ( $attribute_taxonomies ) {
			foreach ( $attribute_taxonomies as $tax ) {
				$name = wc_attribute_taxonomy_name( $tax->attribute_name );

				if ( $name ) {
					$label = ! empty( $tax->attribute_label ) ? $tax->attribute_label : $tax->attribute_name;

					$messages[ $name ] = array(
						0 => '',
						/* translators: %s: taxonomy label */
						1 => sprintf( _x( '%s added', 'taxonomy term messages', 'classic-commerce' ), $label ),
						/* translators: %s: taxonomy label */
						2 => sprintf( _x( '%s deleted', 'taxonomy term messages', 'classic-commerce' ), $label ),
						/* translators: %s: taxonomy label */
						3 => sprintf( _x( '%s updated', 'taxonomy term messages', 'classic-commerce' ), $label ),
						/* translators: %s: taxonomy label */
						4 => sprintf( _x( '%s not added', 'taxonomy term messages', 'classic-commerce' ), $label ),
						/* translators: %s: taxonomy label */
						5 => sprintf( _x( '%s not updated', 'taxonomy term messages', 'classic-commerce' ), $label ),
						/* translators: %s: taxonomy label */
						6 => sprintf( _x( '%s deleted', 'taxonomy term messages', 'classic-commerce' ), $label ),
					);
				}
			}
		}

		return $messages;
	}

	/**
	 * Register our custom post statuses, used for order status.
	 */
	public static function register_post_status() {

		$order_statuses = apply_filters(
			'woocommerce_register_shop_order_post_statuses',
			array(
                'wc-pending'    => array(
					'label'                     => _x( 'Pending payment', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Pending payment <span class="count">(%s)</span>', 'Pending payment <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-processing' => array(
					'label'                     => _x( 'Processing', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Processing <span class="count">(%s)</span>', 'Processing <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-on-hold'    => array(
					'label'                     => _x( 'On hold', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'On hold <span class="count">(%s)</span>', 'On hold <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-completed'  => array(
					'label'                     => _x( 'Completed', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Completed <span class="count">(%s)</span>', 'Completed <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-cancelled'  => array(
					'label'                     => _x( 'Cancelled', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-refunded'   => array(
					'label'                     => _x( 'Refunded', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Refunded <span class="count">(%s)</span>', 'Refunded <span class="count">(%s)</span>', 'classic-commerce' ),
				),
				'wc-failed'     => array(
					'label'                     => _x( 'Failed', 'Order status', 'classic-commerce' ),
					'public'                    => false,
					'exclude_from_search'       => false,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					/* translators: %s: number of orders */
					'label_count'               => _n_noop( 'Failed <span class="count">(%s)</span>', 'Failed <span class="count">(%s)</span>', 'classic-commerce' ),
				),
			)
		);

		foreach ( $order_statuses as $order_status => $values ) {
			register_post_status( $order_status, $values );
		}
	}

	/**
	 * Flush rules if the event is queued.
	 *
	 * @since WC-3.3.0
	 */
	public static function maybe_flush_rewrite_rules() {
		if ( 'yes' === get_option( 'woocommerce_queue_flush_rewrite_rules' ) ) {
			update_option( 'woocommerce_queue_flush_rewrite_rules', 'no' );
			self::flush_rewrite_rules();
		}
	}

	/**
	 * Flush rewrite rules.
	 */
	public static function flush_rewrite_rules() {
		flush_rewrite_rules();
	}

	/**
	 * Added product for Jetpack related posts.
	 *
	 * @param  array $post_types Post types.
	 * @return array
	 */
	public static function rest_api_allowed_post_types( $post_types ) {
		$post_types[] = 'product';

		return $post_types;
	}
}

WC_Post_types::init();
